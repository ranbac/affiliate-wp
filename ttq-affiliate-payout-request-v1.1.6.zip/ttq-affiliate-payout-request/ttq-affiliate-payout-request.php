<?php
/**
 * Plugin Name: TTQ Affiliate Payout Request
 * Description: Cổng yêu cầu rút hoa hồng cho AffiliateWP: dùng Commission Holding Period của AffiliateWP, khóa referral đang chờ, quản trị duyệt/từ chối và ghi nhận Manual Payout.
 * Version: 1.1.6
 * Author: TiengTrungQuoc.net
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class TTQ_Affiliate_Payout_Request {
    const VERSION = '1.1.6';
    const TABLE_SLUG = 'ttq_aff_payout_requests';
    const OPT_MIN = 'ttq_aff_payout_minimum';
    const NONCE = 'ttq_aff_payout_nonce';

    public static function init() {
        register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
        add_shortcode( 'ttq_affiliate_payout_request', array( __CLASS__, 'shortcode' ) );
        add_action( 'wp_ajax_ttq_aff_payout_submit', array( __CLASS__, 'ajax_submit' ) );
        add_action( 'wp_ajax_ttq_aff_payout_cancel', array( __CLASS__, 'ajax_cancel' ) );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ), 99 );
        add_action( 'admin_init', array( __CLASS__, 'handle_admin_action' ) );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_action( 'admin_notices', array( __CLASS__, 'dependency_notice' ) );
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SLUG;
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            request_code VARCHAR(32) NOT NULL,
            affiliate_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            requested_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
            amount DECIMAL(18,4) NOT NULL DEFAULT 0,
            currency VARCHAR(8) NOT NULL DEFAULT 'VND',
            method VARCHAR(32) NOT NULL DEFAULT 'bank',
            account_name VARCHAR(191) NOT NULL DEFAULT '',
            bank_name VARCHAR(191) NOT NULL DEFAULT '',
            account_number LONGTEXT NULL,
            branch VARCHAR(191) NOT NULL DEFAULT '',
            paypal_email VARCHAR(191) NOT NULL DEFAULT '',
            referral_ids LONGTEXT NOT NULL,
            status VARCHAR(24) NOT NULL DEFAULT 'pending',
            note TEXT NULL,
            admin_note TEXT NULL,
            affiliatewp_payout_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY request_code (request_code),
            KEY affiliate_status (affiliate_id,status),
            KEY user_id (user_id)
        ) {$charset};";
        dbDelta( $sql );
        add_option( self::OPT_MIN, 200000 );
    }

    public static function dependency_notice() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! function_exists( 'affiliate_wp' ) || ! function_exists( 'affwp_get_affiliate_id' ) ) {
            echo '<div class="notice notice-warning"><p><strong>TTQ Affiliate Payout Request:</strong> Cần AffiliateWP đang hoạt động để lấy và ghi nhận hoa hồng.</p></div>';
        }
    }

    public static function register_settings() {
        register_setting( 'ttq_aff_payout_settings', self::OPT_MIN, array(
            'type' => 'number', 'sanitize_callback' => array( __CLASS__, 'sanitize_nonnegative' ), 'default' => 200000
        ) );
    }

    public static function sanitize_nonnegative( $v ) {
        return max( 0, (float) $v );
    }

    /**
     * Lấy Commission Holding Period trực tiếp từ AffiliateWP.
     * Không duy trì một giá trị holding riêng để tránh lệch cấu hình.
     *
     * AffiliateWP lưu cấu hình qua settings API; key hiện hành là
     * commission_holding_period. Các nhánh fallback chỉ nhằm tương thích
     * với thay đổi tên key giữa các phiên bản.
     */
    private static function affiliatewp_holding_days() {
        $fallback = 14;

        if ( function_exists( 'affiliate_wp' ) ) {
            $app = affiliate_wp();
            if ( isset( $app->settings ) && method_exists( $app->settings, 'get' ) ) {
                $keys = array(
                    'commission_holding_period',
                    'commission_holding_days',
                    'payout_holding_period',
                );
                foreach ( $keys as $key ) {
                    $value = $app->settings->get( $key, null );
                    if ( null !== $value && '' !== $value && is_numeric( $value ) ) {
                        return max( 0, absint( $value ) );
                    }
                    if ( 0 === $value || '0' === $value ) {
                        return 0;
                    }
                }
            }
        }

        // Fallback đọc option gốc nếu settings object chưa sẵn sàng.
        $raw = get_option( 'affwp_settings', array() );
        if ( is_array( $raw ) ) {
            foreach ( array( 'commission_holding_period', 'commission_holding_days', 'payout_holding_period' ) as $key ) {
                if ( array_key_exists( $key, $raw ) && is_numeric( $raw[ $key ] ) ) {
                    return max( 0, absint( $raw[ $key ] ) );
                }
            }

            // Tương thích dự phòng nếu AffiliateWP đổi tên key nhưng vẫn chứa
            // các từ khóa commission/holding/period.
            foreach ( $raw as $key => $value ) {
                $k = strtolower( (string) $key );
                if ( false !== strpos( $k, 'holding' ) && false !== strpos( $k, 'period' ) && is_numeric( $value ) ) {
                    return max( 0, absint( $value ) );
                }
            }
        }

        return $fallback;
    }

    private static function affiliate_id() {
        if ( ! is_user_logged_in() || ! function_exists( 'affwp_get_affiliate_id' ) ) return 0;
        return absint( affwp_get_affiliate_id( get_current_user_id() ) );
    }

    private static function affiliate_is_active( $affiliate_id ) {
        if ( ! $affiliate_id ) return false;
        if ( function_exists( 'affwp_get_affiliate_status' ) ) {
            return 'active' === affwp_get_affiliate_status( $affiliate_id );
        }
        if ( function_exists( 'affwp_get_affiliate' ) ) {
            $a = affwp_get_affiliate( $affiliate_id );
            if ( ! $a ) return false;
            return ! isset( $a->status ) || 'active' === $a->status;
        }
        return false;
    }

    private static function encrypt( $plain ) {
        $plain = (string) $plain;
        if ( '' === $plain ) return '';
        if ( function_exists( 'openssl_encrypt' ) ) {
            $key = hash( 'sha256', wp_salt( 'auth' ), true );
            $iv = random_bytes( 16 );
            $cipher = openssl_encrypt( $plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
            if ( false !== $cipher ) return 'enc:' . base64_encode( $iv . $cipher );
        }
        return 'b64:' . base64_encode( $plain );
    }

    private static function decrypt( $value ) {
        $value = (string) $value;
        if ( 0 === strpos( $value, 'enc:' ) && function_exists( 'openssl_decrypt' ) ) {
            $raw = base64_decode( substr( $value, 4 ), true );
            if ( false !== $raw && strlen( $raw ) > 16 ) {
                $iv = substr( $raw, 0, 16 );
                $cipher = substr( $raw, 16 );
                $key = hash( 'sha256', wp_salt( 'auth' ), true );
                $plain = openssl_decrypt( $cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
                if ( false !== $plain ) return $plain;
            }
        }
        if ( 0 === strpos( $value, 'b64:' ) ) {
            $plain = base64_decode( substr( $value, 4 ), true );
            return false === $plain ? '' : $plain;
        }
        return $value;
    }

    private static function mask_account( $value ) {
        $v = preg_replace( '/\s+/', '', (string) $value );
        $len = strlen( $v );
        if ( $len <= 4 ) return $v;
        return str_repeat( '•', max( 4, $len - 4 ) ) . substr( $v, -4 );
    }

    private static function all_referrals( $affiliate_id, $status ) {
        if ( ! function_exists( 'affiliate_wp' ) ) return array();
        $app = affiliate_wp();
        if ( ! isset( $app->referrals ) || ! method_exists( $app->referrals, 'get_referrals' ) ) return array();
        $rows = $app->referrals->get_referrals( array(
            'number' => -1,
            'affiliate_id' => absint( $affiliate_id ),
            'status' => $status,
            'orderby' => 'date',
            'order' => 'ASC',
        ) );
        return is_array( $rows ) ? $rows : array();
    }

    private static function locked_referral_ids( $affiliate_id ) {
        global $wpdb;
        $table = self::table();
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT referral_ids FROM {$table} WHERE affiliate_id=%d AND status IN ('pending','approved')",
            absint( $affiliate_id )
        ) );
        $locked = array();
        foreach ( $rows as $csv ) {
            foreach ( preg_split( '/\s*,\s*/', (string) $csv, -1, PREG_SPLIT_NO_EMPTY ) as $id ) {
                $locked[ absint( $id ) ] = true;
            }
        }
        return $locked;
    }

    private static function referral_id( $ref ) {
        if ( isset( $ref->referral_id ) ) return absint( $ref->referral_id );
        if ( isset( $ref->ID ) ) return absint( $ref->ID );
        return 0;
    }

    private static function stats( $affiliate_id ) {
        $hold_days = self::affiliatewp_holding_days();
        $cutoff = current_time( 'timestamp', true ) - ( $hold_days * DAY_IN_SECONDS );
        $locked = self::locked_referral_ids( $affiliate_id );
        $unpaid = self::all_referrals( $affiliate_id, 'unpaid' );
        $paid = self::all_referrals( $affiliate_id, 'paid' );

        $eligible = array();
        $available = 0.0;
        $waiting = 0.0;
        $unpaid_total = 0.0;

        foreach ( $unpaid as $r ) {
            $id = self::referral_id( $r );
            $amount = (float) $r->amount;
            $unpaid_total += $amount;
            $date_ts = ! empty( $r->date ) ? strtotime( $r->date . ' UTC' ) : 0;
            $mature = $date_ts && $date_ts <= $cutoff;
            if ( $mature && empty( $locked[ $id ] ) ) {
                $eligible[] = $r;
                $available += $amount;
            } else {
                $waiting += $amount;
            }
        }

        $paid_total = 0.0;
        foreach ( $paid as $r ) $paid_total += (float) $r->amount;

        return array(
            'eligible' => $eligible,
            'available' => $available,
            'waiting' => $waiting,
            'paid' => $paid_total,
            'total' => $paid_total + $unpaid_total,
            'hold_days' => $hold_days,
        );
    }

    private static function fmt( $amount ) {
        // Hiển thị tiền theo định dạng Việt Nam, không dùng ký hiệu/định dạng kỹ thuật của hệ thống tích hợp.
        return number_format( (float) $amount, 0, ',', '.' ) . ' ₫';
    }

    private static function select_referrals_for_amount( $eligible, $requested ) {
        $requested = (float) $requested;
        $sum = 0.0;
        $ids = array();
        if ( $requested <= 0 ) return array( array(), 0.0 );

        $available = 0.0;
        foreach ( $eligible as $r ) $available += (float) $r->amount;
        if ( $requested >= $available - 0.0001 ) {
            foreach ( $eligible as $r ) $ids[] = self::referral_id( $r );
            return array( array_values( array_filter( $ids ) ), $available );
        }

        // Preserve oldest-first fairness. Only whole AffiliateWP referrals are included.
        foreach ( $eligible as $r ) {
            $amount = (float) $r->amount;
            if ( $sum + $amount <= $requested + 0.0001 ) {
                $id = self::referral_id( $r );
                if ( $id ) {
                    $ids[] = $id;
                    $sum += $amount;
                }
            }
        }
        return array( $ids, $sum );
    }

    private static function active_request( $affiliate_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table() . " WHERE affiliate_id=%d AND status IN ('pending','approved') ORDER BY id DESC LIMIT 1",
            absint( $affiliate_id )
        ) );
    }

    public static function ajax_submit() {
        check_ajax_referer( self::NONCE, 'nonce' );
        if ( ! is_user_logged_in() ) wp_send_json_error( array( 'message' => 'Vui lòng đăng nhập.' ), 401 );
        if ( ! function_exists( 'affiliate_wp' ) ) wp_send_json_error( array( 'message' => 'Hệ thống hoa hồng hiện chưa sẵn sàng. Vui lòng thử lại sau.' ), 500 );

        $affiliate_id = self::affiliate_id();
        if ( ! self::affiliate_is_active( $affiliate_id ) ) {
            wp_send_json_error( array( 'message' => 'Tài khoản cộng tác viên của bạn hiện chưa hoạt động.' ), 403 );
        }

        global $wpdb;
        $lock_name = 'ttq_aff_payout_' . $affiliate_id;
        $got_lock = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) );
        if ( 1 !== $got_lock ) wp_send_json_error( array( 'message' => 'Hệ thống đang xử lý một yêu cầu khác. Vui lòng thử lại.' ), 409 );

        try {
            if ( self::active_request( $affiliate_id ) ) {
                wp_send_json_error( array( 'message' => 'Bạn đang có một yêu cầu rút tiền chưa hoàn tất.' ), 409 );
            }

            $requested = isset( $_POST['amount'] ) ? (float) str_replace( array( ',', ' ' ), '', wp_unslash( $_POST['amount'] ) ) : 0;
            $minimum = (float) get_option( self::OPT_MIN, 200000 );
            if ( $requested < $minimum ) {
                wp_send_json_error( array( 'message' => 'Số tiền yêu cầu phải từ ' . self::fmt( $minimum ) . '.' ), 422 );
            }

            $stats = self::stats( $affiliate_id );
            if ( $stats['available'] < $minimum ) {
                wp_send_json_error( array( 'message' => 'Số dư khả dụng chưa đạt mức rút tối thiểu.' ), 422 );
            }
            if ( $requested > $stats['available'] ) $requested = $stats['available'];

            list( $referral_ids, $actual ) = self::select_referrals_for_amount( $stats['eligible'], $requested );
            if ( empty( $referral_ids ) || $actual < $minimum ) {
                wp_send_json_error( array( 'message' => 'Số tiền này chưa phù hợp với các khoản hoa hồng đang có. Hãy chọn số tiền lớn hơn hoặc chọn Rút toàn bộ.' ), 422 );
            }

            $method = isset( $_POST['method'] ) ? sanitize_key( wp_unslash( $_POST['method'] ) ) : 'bank';
            if ( ! in_array( $method, array( 'bank', 'paypal' ), true ) ) $method = 'bank';
            $account_name = isset( $_POST['account_name'] ) ? sanitize_text_field( wp_unslash( $_POST['account_name'] ) ) : '';
            $bank_name = isset( $_POST['bank_name'] ) ? sanitize_text_field( wp_unslash( $_POST['bank_name'] ) ) : '';
            $account_number = isset( $_POST['account_number'] ) ? sanitize_text_field( wp_unslash( $_POST['account_number'] ) ) : '';
            $branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';
            $paypal_email = isset( $_POST['paypal_email'] ) ? sanitize_email( wp_unslash( $_POST['paypal_email'] ) ) : '';
            $note = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '';

            if ( 'bank' === $method && ( '' === $account_name || '' === $bank_name || '' === $account_number ) ) {
                wp_send_json_error( array( 'message' => 'Vui lòng nhập đủ chủ tài khoản, ngân hàng và số tài khoản.' ), 422 );
            }
            if ( 'paypal' === $method && ! is_email( $paypal_email ) ) {
                wp_send_json_error( array( 'message' => 'Email PayPal không hợp lệ.' ), 422 );
            }

            $now = current_time( 'mysql', true );
            $code = 'PAY-' . gmdate( 'ymd' ) . '-' . strtoupper( wp_generate_password( 5, false, false ) );
            $ok = $wpdb->insert( self::table(), array(
                'request_code' => $code,
                'affiliate_id' => $affiliate_id,
                'user_id' => get_current_user_id(),
                'requested_amount' => $requested,
                'amount' => $actual,
                'currency' => function_exists( 'affwp_get_currency' ) ? affwp_get_currency() : 'VND',
                'method' => $method,
                'account_name' => $account_name,
                'bank_name' => $bank_name,
                'account_number' => self::encrypt( $account_number ),
                'branch' => $branch,
                'paypal_email' => $paypal_email,
                'referral_ids' => implode( ',', array_map( 'absint', $referral_ids ) ),
                'status' => 'pending',
                'note' => $note,
                'created_at' => $now,
                'updated_at' => $now,
            ), array( '%s','%d','%d','%f','%f','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ) );

            if ( ! $ok ) wp_send_json_error( array( 'message' => 'Không thể lưu yêu cầu. Vui lòng thử lại.' ), 500 );

            $admin_email = get_option( 'admin_email' );
            wp_mail( $admin_email, '[Affiliate Payout] ' . $code, 'Có yêu cầu rút hoa hồng mới: ' . $code . ' - ' . self::fmt( $actual ) . '. Vào WordPress Admin → AffiliateWP → Request Payouts để xử lý.' );

            wp_send_json_success( array(
                'message' => 'Đã gửi yêu cầu ' . $code . ' với số tiền ' . self::fmt( $actual ) . '.',
                'actual_amount' => $actual,
                'code' => $code,
            ) );
        } finally {
            $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
        }
    }

    public static function ajax_cancel() {
        check_ajax_referer( self::NONCE, 'nonce' );
        if ( ! is_user_logged_in() ) wp_send_json_error( array( 'message' => 'Vui lòng đăng nhập.' ), 401 );
        $id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
        $affiliate_id = self::affiliate_id();
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id=%d AND affiliate_id=%d', $id, $affiliate_id ) );
        if ( ! $row || 'pending' !== $row->status ) wp_send_json_error( array( 'message' => 'Yêu cầu này không thể hủy.' ), 422 );
        $wpdb->update( self::table(), array( 'status' => 'cancelled', 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ), array( '%s','%s' ), array( '%d' ) );
        wp_send_json_success( array( 'message' => 'Đã hủy yêu cầu.' ) );
    }

    // Customer-facing copy must stay non-technical: do not expose implementation names,
    // storage/encryption details, internal statuses, or integration terminology here.
    public static function shortcode() {
        if ( ! is_user_logged_in() ) {
            return '<div class="ttq-pay-msg">Vui lòng <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">đăng nhập</a> để yêu cầu rút hoa hồng.</div>';
        }
        if ( ! function_exists( 'affiliate_wp' ) || ! function_exists( 'affwp_get_affiliate_id' ) ) {
            return '<div class="ttq-pay-msg">Hệ thống hoa hồng hiện chưa sẵn sàng. Vui lòng thử lại sau.</div>';
        }
        $affiliate_id = self::affiliate_id();
        if ( ! self::affiliate_is_active( $affiliate_id ) ) {
            return '<div class="ttq-pay-msg">Tài khoản của bạn chưa phải cộng tác viên đang hoạt động.</div>';
        }

        $stats = self::stats( $affiliate_id );
        $minimum = (float) get_option( self::OPT_MIN, 200000 );
        global $wpdb;
        $history = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE affiliate_id=%d ORDER BY id DESC LIMIT 50', $affiliate_id ) );
        $nonce = wp_create_nonce( self::NONCE );
        $ajax = admin_url( 'admin-ajax.php' );

        ob_start();
        ?>
        <style>
        .ttq-pr{--bg:#f0f4fa;--surface:#fff;--border:#e2e8f4;--accent:#3b7de8;--green:#1fad6e;--orange:#f59e0b;--red:#e65353;--text:#1e2230;--muted:#7a82a0;font-family:'Be Vietnam Pro',system-ui,sans-serif;color:var(--text);max-width:940px;margin:0 auto;padding:20px 0 44px}.ttq-pr *{box-sizing:border-box}.ttq-pr .head{text-align:center;margin-bottom:24px}.ttq-pr .tag{display:inline-block;padding:5px 15px;border-radius:99px;background:#edf4ff;border:1px solid #d5e4ff;color:var(--accent);font-size:12px;font-weight:700;margin-bottom:11px}.ttq-pr h1{font-size:30px;line-height:1.2;margin:0 0 8px;font-weight:800}.ttq-pr .head p{margin:0;color:var(--muted);font-size:14px}.ttq-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:24px 0}.ttq-stat{background:#fff;border:1.5px solid var(--border);border-radius:16px;padding:17px;box-shadow:0 6px 22px rgba(30,34,48,.04)}.ttq-stat b{display:block;font-size:11px;color:var(--muted);text-transform:uppercase}.ttq-stat strong{display:block;font-size:21px;margin-top:6px}.ttq-stat.av strong{color:var(--green)}.ttq-stat.wait strong{color:var(--orange)}.ttq-stat.paid strong{color:var(--accent)}.ttq-grid{display:grid;grid-template-columns:1.25fr .75fr;gap:16px;align-items:start}.ttq-panel{background:#fff;border:1.5px solid var(--border);border-radius:18px;padding:23px;box-shadow:0 10px 34px rgba(0,0,0,.05)}.ttq-panel h2{font-size:18px;margin:0 0 5px}.ttq-sub{color:var(--muted);font-size:12.5px;line-height:1.55;margin-bottom:18px}.ttq-field{margin-bottom:14px}.ttq-field label{display:block;font-weight:700;font-size:12px;margin-bottom:6px}.ttq-field input,.ttq-field select,.ttq-field textarea{width:100%;border:1.5px solid var(--border);border-radius:11px;padding:11px 12px;font:inherit;font-size:13px;background:#fff}.ttq-field textarea{min-height:72px;resize:vertical}.ttq-two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.ttq-quick{display:flex;flex-wrap:wrap;gap:7px;margin-top:8px}.ttq-quick button{border:1px solid var(--border);background:#f8fafc;border-radius:8px;padding:6px 9px;font-weight:700;font-size:11px;cursor:pointer}.ttq-note{font-size:11px;line-height:1.55;color:#657085;background:#f8fafc;border:1px solid #eef1f7;padding:10px 11px;border-radius:10px;margin-top:9px}.ttq-check{display:flex;gap:8px;align-items:flex-start;font-size:11.5px;color:#5e6678;line-height:1.5;margin:14px 0}.ttq-check input{margin-top:2px}.ttq-submit{width:100%;border:0;border-radius:11px;padding:12px;background:linear-gradient(135deg,var(--accent),#5b9fff);color:#fff;font-weight:800;cursor:pointer}.ttq-submit[disabled]{opacity:.6;cursor:not-allowed}.ttq-rule{display:flex;gap:10px;padding:11px 0;border-bottom:1px solid #eef1f7}.ttq-rule:last-child{border-bottom:0}.ttq-ic{width:29px;height:29px;border-radius:8px;background:#eef3fc;display:flex;align-items:center;justify-content:center;flex:0 0 auto}.ttq-rule b{font-size:12.5px}.ttq-rule p{font-size:11.5px;color:var(--muted);margin:3px 0 0;line-height:1.5}.ttq-history{margin-top:18px}.ttq-table{width:100%;border-collapse:collapse;background:#fff;border:1.5px solid var(--border);border-radius:15px;overflow:hidden;display:table}.ttq-table th,.ttq-table td{padding:11px 12px;border-bottom:1px solid #eef1f7;font-size:11.5px;text-align:left}.ttq-table th{background:#f8fafc;color:#69738b;text-transform:uppercase;font-size:10px}.ttq-badge{display:inline-block;border-radius:99px;padding:4px 8px;font-size:10px;font-weight:800}.s-pending{background:#fff4d6;color:#9b6500}.s-approved{background:#e8f1ff;color:#2d67bb}.s-paid{background:#ddf7e9;color:#127449}.s-rejected,.s-cancelled{background:#f5e7e7;color:#a44848}.ttq-cancel{border:0;background:none;color:#b24a4a;text-decoration:underline;cursor:pointer;padding:0;font-size:11px}.ttq-alert{display:none;margin:0 0 14px;padding:10px 12px;border-radius:10px;font-size:12px;line-height:1.5}.ttq-alert.ok{display:block;background:#e4f8ed;color:#176d49}.ttq-alert.err{display:block;background:#fdeaea;color:#a43f3f}.ttq-paypal{display:none}@media(max-width:760px){.ttq-stats{grid-template-columns:1fr 1fr}.ttq-grid{grid-template-columns:1fr}}@media(max-width:520px){.ttq-two{grid-template-columns:1fr}.ttq-table{display:block;overflow-x:auto;white-space:nowrap}.ttq-pr h1{font-size:25px}}
        </style>
        <div class="ttq-pr" id="ttq-pr" data-ajax="<?php echo esc_url( $ajax ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>" data-available="<?php echo esc_attr( $stats['available'] ); ?>">
          <div class="head"><div class="tag">Thanh toán hoa hồng</div><h1>Yêu cầu rút tiền</h1><p>Chỉ hoa hồng hợp lệ đã qua <?php echo esc_html( $stats['hold_days'] ); ?> ngày đối soát mới có thể rút.</p></div>
          <div class="ttq-stats">
            <div class="ttq-stat av"><b>Có thể rút</b><strong><?php echo wp_kses_post( self::fmt( $stats['available'] ) ); ?></strong></div>
            <div class="ttq-stat wait"><b>Đang chờ xử lý</b><strong><?php echo wp_kses_post( self::fmt( $stats['waiting'] ) ); ?></strong></div>
            <div class="ttq-stat paid"><b>Đã thanh toán</b><strong><?php echo wp_kses_post( self::fmt( $stats['paid'] ) ); ?></strong></div>
            <div class="ttq-stat"><b>Tổng hoa hồng</b><strong><?php echo wp_kses_post( self::fmt( $stats['total'] ) ); ?></strong></div>
          </div>
          <div class="ttq-grid">
            <div class="ttq-panel">
              <h2>Tạo yêu cầu rút tiền</h2><div class="ttq-sub">Kiểm tra số tiền và thông tin nhận tiền trước khi gửi. Mỗi thời điểm bạn chỉ có thể có một yêu cầu đang được xử lý.</div>
              <div id="ttq-alert" class="ttq-alert"></div>
              <form id="ttq-form">
                <div class="ttq-field"><label>Số tiền muốn rút</label><input id="ttq-amount" name="amount" type="number" min="<?php echo esc_attr( $minimum ); ?>" max="<?php echo esc_attr( $stats['available'] ); ?>" step="1000" placeholder="Nhập số tiền"><div class="ttq-quick"><button type="button" data-amt="200000">200.000đ</button><button type="button" data-amt="500000">500.000đ</button><button type="button" data-amt="1000000">1.000.000đ</button><button type="button" data-all="1">Rút toàn bộ</button></div><div class="ttq-note">Mức rút tối thiểu: <strong><?php echo wp_kses_post( self::fmt( $minimum ) ); ?></strong>. Nếu số tiền bạn nhập không khớp chính xác với các khoản hoa hồng đủ điều kiện, hệ thống sẽ tự chọn mức gần nhất nhưng không vượt quá số tiền bạn yêu cầu.</div></div>
                <div class="ttq-field"><label>Phương thức nhận tiền</label><select name="method" id="ttq-method"><option value="bank">Chuyển khoản ngân hàng</option><option value="paypal">PayPal</option></select></div>
                <div class="ttq-bank">
                  <div class="ttq-two"><div class="ttq-field"><label>Họ tên chủ tài khoản</label><input name="account_name" type="text" autocomplete="name"></div><div class="ttq-field"><label>Ngân hàng</label><input name="bank_name" type="text" placeholder="Vietcombank"></div></div>
                  <div class="ttq-two"><div class="ttq-field"><label>Số tài khoản</label><input name="account_number" type="text" inputmode="numeric" autocomplete="off"></div><div class="ttq-field"><label>Chi nhánh (không bắt buộc)</label><input name="branch" type="text"></div></div>
                </div>
                <div class="ttq-paypal"><div class="ttq-field"><label>Email PayPal</label><input name="paypal_email" type="email"></div></div>
                <div class="ttq-field"><label>Ghi chú</label><textarea name="note" placeholder="Thông tin bổ sung nếu có"></textarea></div>
                <label class="ttq-check"><input id="ttq-agree" type="checkbox"><span>Tôi xác nhận thông tin nhận tiền là chính xác và đồng ý để yêu cầu được kiểm tra trước khi thanh toán.</span></label>
                <button class="ttq-submit" id="ttq-submit" type="submit">Gửi yêu cầu rút tiền</button>
              </form>
            </div>
            <div class="ttq-panel"><h2>Điều kiện thanh toán</h2><div class="ttq-sub">Yêu cầu rút tiền sẽ được xử lý khi đáp ứng đầy đủ các điều kiện dưới đây.</div>
              <div class="ttq-rule"><div class="ttq-ic">✓</div><div><b>Tài khoản đang hoạt động</b><p>Tài khoản cộng tác viên của bạn phải đang ở trạng thái hoạt động.</p></div></div>
              <div class="ttq-rule"><div class="ttq-ic">⏱</div><div><b>Qua thời gian đối soát</b><p>Hoa hồng cần đủ <?php echo esc_html( $stats['hold_days'] ); ?> ngày đối soát trước khi có thể rút.</p></div></div>
              <div class="ttq-rule"><div class="ttq-ic">↺</div><div><b>Chỉ tính hoa hồng đủ điều kiện</b><p>Các khoản bị hủy, hoàn tiền hoặc không còn hợp lệ sẽ không được tính vào số dư có thể rút.</p></div></div>
              <div class="ttq-rule"><div class="ttq-ic">1</div><div><b>Không gửi yêu cầu mới khi đang chờ xử lý</b><p>Khoản hoa hồng đã nằm trong một yêu cầu đang xử lý sẽ tạm thời không thể yêu cầu lại.</p></div></div>
              <div class="ttq-note">🔒 Thông tin nhận tiền của bạn được bảo mật và chỉ được sử dụng để xử lý yêu cầu thanh toán.</div>
            </div>
          </div>
          <div class="ttq-history"><h2>Lịch sử yêu cầu rút tiền</h2><div style="overflow-x:auto"><table class="ttq-table"><thead><tr><th>Ngày</th><th>Mã yêu cầu</th><th>Số tiền</th><th>Phương thức</th><th>Trạng thái</th><th></th></tr></thead><tbody>
          <?php if ( empty( $history ) ) : ?><tr><td colspan="6">Chưa có yêu cầu rút tiền nào.</td></tr><?php else : foreach ( $history as $h ) : ?>
            <tr><td><?php echo esc_html( get_date_from_gmt( $h->created_at, 'd/m/Y H:i' ) ); ?></td><td><?php echo esc_html( $h->request_code ); ?></td><td><strong><?php echo wp_kses_post( self::fmt( $h->amount ) ); ?></strong></td><td><?php echo esc_html( 'paypal' === $h->method ? 'PayPal' : 'Ngân hàng' ); ?></td><td><span class="ttq-badge s-<?php echo esc_attr( $h->status ); ?>"><?php echo esc_html( self::status_label( $h->status ) ); ?></span></td><td><?php if ( 'pending' === $h->status ) : ?><button class="ttq-cancel" data-id="<?php echo absint( $h->id ); ?>">Hủy</button><?php endif; ?></td></tr>
          <?php endforeach; endif; ?></tbody></table></div></div>
        </div>
        <script>(function(){const root=document.getElementById('ttq-pr');if(!root)return;const ajax=root.dataset.ajax,nonce=root.dataset.nonce,available=parseFloat(root.dataset.available||'0');const form=document.getElementById('ttq-form'),amount=document.getElementById('ttq-amount'),method=document.getElementById('ttq-method'),bank=root.querySelector('.ttq-bank'),paypal=root.querySelector('.ttq-paypal'),alertBox=document.getElementById('ttq-alert'),submit=document.getElementById('ttq-submit');function msg(t,ok){alertBox.className='ttq-alert '+(ok?'ok':'err');alertBox.textContent=t;alertBox.scrollIntoView({behavior:'smooth',block:'nearest'});}root.querySelectorAll('.ttq-quick button').forEach(b=>b.addEventListener('click',()=>{amount.value=b.dataset.all?available:(b.dataset.amt||'');}));method.addEventListener('change',()=>{const pp=method.value==='paypal';bank.style.display=pp?'none':'block';paypal.style.display=pp?'block':'none';});form.addEventListener('submit',async e=>{e.preventDefault();if(!document.getElementById('ttq-agree').checked){msg('Vui lòng xác nhận thông tin trước khi gửi.',false);return;}submit.disabled=true;submit.textContent='Đang gửi...';const fd=new FormData(form);fd.append('action','ttq_aff_payout_submit');fd.append('nonce',nonce);try{const r=await fetch(ajax,{method:'POST',credentials:'same-origin',body:fd});const j=await r.json();msg((j.data&&j.data.message)||'Có lỗi xảy ra.',!!j.success);if(j.success)setTimeout(()=>location.reload(),900);}catch(e){msg('Không thể kết nối máy chủ.',false);}finally{submit.disabled=false;submit.textContent='Gửi yêu cầu rút tiền';}});root.querySelectorAll('.ttq-cancel').forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Hủy yêu cầu này?'))return;const fd=new FormData();fd.append('action','ttq_aff_payout_cancel');fd.append('nonce',nonce);fd.append('id',b.dataset.id);const r=await fetch(ajax,{method:'POST',credentials:'same-origin',body:fd});const j=await r.json();msg((j.data&&j.data.message)||'Có lỗi xảy ra.',!!j.success);if(j.success)setTimeout(()=>location.reload(),700);}));})();</script>
        <?php
        return ob_get_clean();
    }

    private static function status_label( $status ) {
        $m = array( 'pending'=>'Chờ xử lý', 'approved'=>'Đã duyệt', 'paid'=>'Đã thanh toán', 'rejected'=>'Từ chối', 'cancelled'=>'Đã hủy' );
        return isset( $m[ $status ] ) ? $m[ $status ] : $status;
    }

    public static function admin_menu() {
        add_submenu_page( 'affiliate-wp', 'Request Payouts', 'Request Payouts', 'manage_options', 'ttq-affiliate-payouts', array( __CLASS__, 'admin_page' ) );
        add_options_page( 'Affiliate Payout Settings', 'Affiliate Payout', 'manage_options', 'ttq-affiliate-payout-settings', array( __CLASS__, 'settings_page' ) );
    }

    public static function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap"><h1>Cài đặt Affiliate Payout</h1><form method="post" action="options.php"><?php settings_fields( 'ttq_aff_payout_settings' ); ?>
        <table class="form-table">
          <tr><th>Mức rút tối thiểu</th><td><input type="number" name="<?php echo esc_attr( self::OPT_MIN ); ?>" value="<?php echo esc_attr( get_option( self::OPT_MIN, 200000 ) ); ?>" min="0" step="1000"> <span>theo đơn vị tiền tệ AffiliateWP</span></td></tr>
          <tr><th>Commission Holding Period</th><td><strong><?php echo esc_html( self::affiliatewp_holding_days() ); ?> ngày</strong><p class="description">Giá trị này được đọc trực tiếp từ AffiliateWP → Settings → Commissions. Plugin TTQ không lưu một thời gian giữ riêng.</p></td></tr>
        </table><?php submit_button(); ?></form></div>
        <?php
    }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        global $wpdb;
        $rows = $wpdb->get_results( 'SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT 500' );
        $msg = isset( $_GET['ttq_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['ttq_msg'] ) ) : '';
        ?>
        <div class="wrap"><h1>Affiliate Request Payouts</h1>
        <?php if ( $msg ) : ?><div class="notice notice-info is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
        <p><strong>Lưu ý:</strong> nút “Đã chuyển tiền + ghi nhận” không tự chuyển khoản ngân hàng. Hãy chuyển tiền thực tế trước, sau đó bấm nút này để tạo Manual Payout trong AffiliateWP và chuyển các referral tương ứng sang Paid.</p>
        <p><a class="button" href="<?php echo esc_url( admin_url( 'options-general.php?page=ttq-affiliate-payout-settings' ) ); ?>">Cài đặt mức rút / xem thời gian giữ</a></p>
        <table class="widefat striped"><thead><tr><th>ID</th><th>Affiliate</th><th>Ngày</th><th>Số tiền</th><th>Nhận tiền</th><th>Referral IDs</th><th>Trạng thái</th><th>Xử lý</th></tr></thead><tbody>
        <?php if ( empty( $rows ) ) : ?><tr><td colspan="8">Chưa có yêu cầu.</td></tr><?php else : foreach ( $rows as $r ) : $u=get_userdata($r->user_id); $acc=self::decrypt($r->account_number); ?>
          <tr><td><?php echo esc_html( $r->request_code ); ?></td><td>#<?php echo absint( $r->affiliate_id ); ?> — <?php echo esc_html( $u ? $u->user_login : 'User '.$r->user_id ); ?></td><td><?php echo esc_html( get_date_from_gmt( $r->created_at, 'd/m/Y H:i' ) ); ?></td><td><strong><?php echo wp_kses_post( self::fmt( $r->amount ) ); ?></strong><?php if ( abs( (float)$r->requested_amount - (float)$r->amount ) > 0.0001 ) echo '<br><small>Yêu cầu: '.wp_kses_post(self::fmt($r->requested_amount)).'</small>'; ?></td><td><?php if('paypal'===$r->method){echo 'PayPal<br><code>'.esc_html($r->paypal_email).'</code>';}else{echo esc_html($r->account_name).'<br>'.esc_html($r->bank_name).'<br><code>'.esc_html($acc).'</code>'; if($r->branch) echo '<br>'.esc_html($r->branch);} ?></td><td><code><?php echo esc_html( $r->referral_ids ); ?></code></td><td><?php echo esc_html( self::status_label( $r->status ) ); ?><?php if($r->affiliatewp_payout_id) echo '<br><small>AffiliateWP Payout #'.absint($r->affiliatewp_payout_id).'</small>'; ?></td><td><?php self::admin_actions( $r ); ?></td></tr>
        <?php endforeach; endif; ?></tbody></table></div>
        <?php
    }

    private static function action_url( $id, $do ) {
        return wp_nonce_url( add_query_arg( array( 'page'=>'ttq-affiliate-payouts','ttq_payout_action'=>$do,'request_id'=>absint($id) ), admin_url( 'admin.php' ) ), 'ttq_payout_admin_' . absint($id) . '_' . $do );
    }

    private static function admin_actions( $r ) {
        if ( 'pending' === $r->status ) {
            echo '<a class="button button-primary" href="' . esc_url( self::action_url( $r->id, 'approve' ) ) . '">Duyệt</a> ';
            echo '<a class="button" href="' . esc_url( self::action_url( $r->id, 'reject' ) ) . '">Từ chối</a>';
        } elseif ( 'approved' === $r->status ) {
            echo '<a class="button button-primary" onclick="return confirm(\'Bạn đã thực sự chuyển tiền cho affiliate? Thao tác này sẽ ghi Manual Payout vào AffiliateWP và đánh dấu các referral là Paid.\')" href="' . esc_url( self::action_url( $r->id, 'pay' ) ) . '">Đã chuyển tiền + ghi nhận</a> ';
            echo '<a class="button" href="' . esc_url( self::action_url( $r->id, 'reject' ) ) . '">Từ chối</a>';
        } else {
            echo '—';
        }
    }

    public static function handle_admin_action() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) return;
        if ( empty( $_GET['ttq_payout_action'] ) || empty( $_GET['request_id'] ) ) return;
        $do = sanitize_key( wp_unslash( $_GET['ttq_payout_action'] ) );
        $id = absint( $_GET['request_id'] );
        check_admin_referer( 'ttq_payout_admin_' . $id . '_' . $do );
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id=%d', $id ) );
        if ( ! $row ) self::admin_redirect( 'Không tìm thấy yêu cầu.' );

        if ( 'approve' === $do && 'pending' === $row->status ) {
            $wpdb->update( self::table(), array( 'status'=>'approved','updated_at'=>current_time('mysql',true) ), array('id'=>$id), array('%s','%s'), array('%d') );
            self::admin_redirect( 'Đã duyệt ' . $row->request_code . '. Hãy chuyển tiền thực tế trước khi ghi nhận đã thanh toán.' );
        }

        if ( 'reject' === $do && in_array( $row->status, array('pending','approved'), true ) ) {
            $wpdb->update( self::table(), array( 'status'=>'rejected','updated_at'=>current_time('mysql',true) ), array('id'=>$id), array('%s','%s'), array('%d') );
            self::admin_redirect( 'Đã từ chối ' . $row->request_code . '. Các referral đã được mở khóa.' );
        }

        if ( 'pay' === $do && 'approved' === $row->status ) {
            if ( ! function_exists( 'affwp_add_payout' ) || ! function_exists( 'affwp_get_referral' ) ) {
                self::admin_redirect( 'AffiliateWP chưa sẵn sàng để tạo payout.' );
            }
            $ids = array_values( array_filter( array_map( 'absint', preg_split('/\s*,\s*/', $row->referral_ids, -1, PREG_SPLIT_NO_EMPTY ) ) ) );
            if ( empty( $ids ) ) self::admin_redirect( 'Yêu cầu không có referral hợp lệ.' );
            $sum = 0.0;
            foreach ( $ids as $rid ) {
                $ref = affwp_get_referral( $rid );
                if ( ! $ref || absint( $ref->affiliate_id ) !== absint( $row->affiliate_id ) || 'unpaid' !== $ref->status ) {
                    self::admin_redirect( 'Không thể thanh toán: Referral #' . $rid . ' không còn ở trạng thái Unpaid hoặc không thuộc affiliate này. Không có dữ liệu nào bị thay đổi.' );
                }
                $sum += (float) $ref->amount;
            }
            if ( abs( $sum - (float) $row->amount ) > 0.01 ) {
                self::admin_redirect( 'Không thể thanh toán: tổng referral hiện tại không khớp số tiền yêu cầu.' );
            }
            $payout_id = affwp_add_payout( array(
                'affiliate_id' => absint( $row->affiliate_id ),
                'referrals' => $ids,
                'amount' => $sum,
                'payout_method' => 'manual',
                'status' => 'paid',
                'description' => 'TTQ Request Payout ' . $row->request_code,
            ) );
            if ( ! $payout_id ) self::admin_redirect( 'AffiliateWP không tạo được payout. Vui lòng kiểm tra log.' );
            $wpdb->update( self::table(), array( 'status'=>'paid','affiliatewp_payout_id'=>absint($payout_id),'updated_at'=>current_time('mysql',true) ), array('id'=>$id), array('%s','%d','%s'), array('%d') );
            self::admin_redirect( 'Đã ghi nhận ' . $row->request_code . ' thành AffiliateWP Manual Payout #' . absint( $payout_id ) . '.' );
        }
    }

    private static function admin_redirect( $msg ) {
        wp_safe_redirect( add_query_arg( array( 'page'=>'ttq-affiliate-payouts','ttq_msg'=>$msg ), admin_url( 'admin.php' ) ) );
        exit;
    }
}

TTQ_Affiliate_Payout_Request::init();
